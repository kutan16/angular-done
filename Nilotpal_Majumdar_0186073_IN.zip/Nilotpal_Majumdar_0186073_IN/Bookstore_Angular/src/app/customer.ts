export class Customer {
   
    emailId: string;
    name: string;
    phoneNo: string;
    password: string;
    address: string;
    city: string;
    country: string;
    zipCode: string;
}