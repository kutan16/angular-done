package com.cg.book.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name = "customer2")
public class Customer {
 
  
//  @GeneratedValue(strategy = GenerationType.AUTO)
//  private long id;
  private String name;
  @Id
  private String emailId;
  private String phoneNo;
  private String password;
  private String city;
  private String country;
  private String address;
  private String zipCode;
  
  public Customer() {
  }


public Customer(String name, String emailId, String phoneNo, String password, String city, String country,
		String address, String zipCode) {
	super();
	this.name = name;
	this.emailId = emailId;
	this.phoneNo = phoneNo;
	this.password = password;
	this.city = city;
	this.country = country;
	this.address = address;
	this.zipCode = zipCode;
}






public String getPassword() {
	return password;
}




public void setPassword(String password) {
	this.password = password;
}




public String getCity() {
	return city;
}




public void setCity(String city) {
	this.city = city;
}




public String getCountry() {
	return country;
}




public void setCountry(String country) {
	this.country = country;
}








public String getAddress() {
	return address;
}




public void setAddress(String address) {
	this.address = address;
}

 
  public void setName(String name) {
    this.name = name;
  }
 
  public String getName() {
    return this.name;
  }

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}


public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}


public String getZipCode() {
	return zipCode;
}


public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}


@Override
public String toString() {
	return "Customer [name=" + name + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", password=" + password
			+ ", city=" + city + ", country=" + country + ", address=" + address + ", zipCode=" + zipCode + "]";
}







 

 
//  public boolean isActive() {
//    return active;
//  }
// 
//  public void setActive(boolean active) {
//    this.active = active;
//  }
 
  
}