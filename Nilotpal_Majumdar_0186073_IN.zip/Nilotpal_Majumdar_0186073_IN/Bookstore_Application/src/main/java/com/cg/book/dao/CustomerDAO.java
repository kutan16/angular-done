package com.cg.book.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.book.beans.Customer;
 
public interface CustomerDAO extends JpaRepository<Customer, String> {
  //List<DemoCustomer> findByAge(int age);
}
