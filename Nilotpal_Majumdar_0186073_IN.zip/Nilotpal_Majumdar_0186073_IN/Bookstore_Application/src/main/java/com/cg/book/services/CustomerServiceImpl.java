package com.cg.book.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.book.beans.Customer;
import com.cg.book.dao.CustomerDAO;
import com.cg.book.exception.CustomerDetailsNotFoundException;
@Component("customerServices")
public class CustomerServiceImpl implements CustomerService{

	
	@Autowired
	CustomerDAO customerRepo;
	
	@Override
	public Customer createCustomer(Customer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomer(String emailId) throws CustomerDetailsNotFoundException {
		return customerRepo.findById(emailId).orElseThrow(()-> new 
				CustomerDetailsNotFoundException("Customer Details Not Found"));
	}

	@Override
	public boolean deleteCustomer(String emailId) throws CustomerDetailsNotFoundException {
		customerRepo.deleteById(emailId);
		return false;
	}

	@Override
	public Customer updateCustomer(String emailId, Customer customer) throws CustomerDetailsNotFoundException {
		customerRepo.findById(emailId).orElseThrow(()-> new CustomerDetailsNotFoundException("Customer details not found"));	
		return customerRepo.save(customer);
	}

}
