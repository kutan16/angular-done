package com.cg.book.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.book.beans.Customer;
import com.cg.book.exception.CustomerDetailsNotFoundException;

public interface CustomerService {

	
	Customer createCustomer(Customer customer);
	Customer getCustomer(String emailId)throws CustomerDetailsNotFoundException;
	List<Customer> getAllCustomer()throws CustomerDetailsNotFoundException;
	boolean deleteCustomer(String emailId)throws CustomerDetailsNotFoundException;
	Customer updateCustomer(String emailId,Customer customer)throws CustomerDetailsNotFoundException;
	
}
